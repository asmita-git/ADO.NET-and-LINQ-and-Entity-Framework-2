﻿using PKRTravelsManagement.Models;
using Sitecore.FakeDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using Microsoft.Extensions.Configuration;
using System.Configuration;

namespace PKRTravelsManagement.Controllers
{
    public class PKRTravelsController : Controller
    {

        PKR_travelsEntities2 db = new PKR_travelsEntities2();
       


        // GET: PKRTravels
        public ActionResult Index()
        {
            var Data = db.BusInfoes.ToList();
           
            return View(Data);
        }

        

        // GET: PKRTravels/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: PKRTravels/Create
        [HttpPost]
        public ActionResult Create(BusInfo B)
        { // TODO: Add insert logic here
            
                if (ModelState.IsValid == true)
                {

                }
                db.BusInfoes.Add(B);
                int a = db.SaveChanges();
                if (a > 0)
                {
                    TempData["SuccessMsg"] = "Save Successfully!"; 
                    return RedirectToAction("Index");

                }
                else
                {
                    TempData["InsertaMessage"] = "Not Succesfully";
                }
            return View(a);


           // return RedirectToAction("Index");
        }
           
        

    }
}
